package https://fhir.nhs.uk/R4/ImplementationGuide/nhsdigital-fhir-r4-core-prototype;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class ExtensionUKCoreEthnicCategory {

}
